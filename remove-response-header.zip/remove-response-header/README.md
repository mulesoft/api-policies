### Remove Response Header Policy ###

#### Description

This policy can be used with API Gateway to remove certain headers of the response, when passing through the proxy, before hitting the client. The headers can be provided by the backend service or another policy.

Example use case:

This policy is useful if you have security concerns regarding the headers that the backend service is sending.

#### Configuration

After adding the custom policy to API Platform, you will have the posibility to include it in your API. 
If you apply it, you will see a text area where you can include the header name to be removed. You can add multiple headers by separating them using comma.
Once you finished including your headers, you can press Apply and the policy will start working (if you have an API Gateway already paired to your API).
You can also edit it whenever you want, by clicking the Edit button.
